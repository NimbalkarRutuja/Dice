package com.WeatherAPI.Weatherforecast;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherforecastApplicationTests {

	@Test
	void contextLoads() {
	}

}
