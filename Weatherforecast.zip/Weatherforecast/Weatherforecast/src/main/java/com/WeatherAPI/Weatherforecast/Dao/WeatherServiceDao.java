package com.WeatherAPI.Weatherforecast.Dao;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.WeatherAPI.Weatherforecast.Model.WeatherForecast;
import com.WeatherAPI.Weatherforecast.Service.WeatherService;

@Service
public class WeatherServiceDao implements WeatherService{

	//private static final String API_URL = "https://rapidweather.p.rapidapi.com/data/2.5/weather";
	private static final String API_URL = "https://forecast9.p.rapidapi.com/";
	private static final String API_KEY = "7b3758a777mshc4bf1ab0a15c428p1cd93ajsn4c9d963a6f33";

	
    private final RestTemplate restTemplate;

    public WeatherServiceDao(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Override
    public WeatherForecast getWeatherForecast(String city) {
        String url = API_URL.replace("{city}", city).replace("{apiKey}", API_KEY);
        return restTemplate.getForObject(url, WeatherForecast.class);
    }
}
